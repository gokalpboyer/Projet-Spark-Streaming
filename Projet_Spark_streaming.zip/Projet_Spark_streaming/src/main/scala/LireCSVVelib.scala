import org.apache.spark.sql.SparkSession
import java.io.{File, FileWriter, BufferedWriter}
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object LireCSVVelib {
  def main(args: Array[String]): Unit = {
    // Créer une session Spark
    val spark = SparkSession.builder
      .appName("LireCSVVelib")
      .master("local[*]") // Exécuter localement avec toutes les CPU disponibles
      .getOrCreate()

    // Lire le fichier CSV
    val filePath = "C:\\Users\\DELL\\Downloads\\Projet_Spark_streaming\\input\\velib-disponibilite-en-temps-reel.csv"
    val df = spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .option("delimiter", ";") // Spécifier le délimiteur correct
      .csv(filePath)

    // Définir le chemin du répertoire de sortie
    val outputDir = "C:\\Users\\DELL\\Downloads\\Projet_Spark_streaming\\output"
    val logFile = s"$outputDir\\log.txt"

    val totalRows = df.count().toInt
    val batchSize = 10

    // Initialiser le fichier de log
    val logWriter = new BufferedWriter(new FileWriter(new File(logFile), true))

    // Formatter pour l'heure de création des fichiers
    val formatter = DateTimeFormatter.ofPattern("yyyy.MM.dd_HH.mm.ss")

    // Boucle pour traiter les lignes par blocs de 10
    for (start <- 0 until totalRows by batchSize) {
      val end = math.min(start + batchSize, totalRows)
      val limitedDF = df.limit(end).except(df.limit(start))
      val rows = limitedDF.collect()

      // Journaliser les indices de début et de fin et le nombre de lignes traitées
      val logMessage = s"Traitement des lignes de $start à ${end - 1}. Nombre de lignes traitées: ${rows.length}"
      println(logMessage) // Afficher dans la console
      logWriter.write(logMessage + "\n") // Écrire dans le fichier de log

      // Obtenir l'heure actuelle
      val currentTime = LocalDateTime.now().format(formatter)

      // Définir le nom du fichier de sortie
      val outputFile = s"$outputDir\\resultat_velib_$currentTime.csv"

      // Écrire les en-têtes et les lignes dans le fichier CSV
      val writer = new BufferedWriter(new FileWriter(new File(outputFile)))
      writer.write(df.columns.mkString(";") + "\n") // Écrire les en-têtes
      rows.foreach(row => writer.write(row.mkString(";") + "\n"))
      writer.close()
    }

    logWriter.close()

    println(s"Les lignes ont été écrites dans le répertoire : $outputDir")
    println(s"Les logs ont été écrits dans le fichier : $logFile")

    // Arrêter la session Spark
    spark.stop()
  }
}