import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StructType, StringType, IntegerType}
import java.io.{File, PrintWriter}
import java.nio.file.{Files, Paths, StandardOpenOption}
import scala.collection.JavaConverters._
import java.time.{LocalDateTime, Duration}

object application {
  // Variable globale pour l'intervalle d'attente en minutes
  var intervalMinutes: Int = 3

  def main(args: Array[String]): Unit = {
    // Configurer le niveau de journalisation
    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)

    // Créer une session Spark
    val spark = SparkSession.builder
      .appName("CalculerKPIs")
      .master("local[*]") // Exécuter localement avec toutes les CPU disponibles
      .getOrCreate()

    import spark.implicits._

    // Définir le schéma des données
    val schema = new StructType()
      .add("stationcode", StringType)
      .add("name", StringType)
      .add("is_installed", StringType)
      .add("capacity", IntegerType)
      .add("numdocksavailable", IntegerType)
      .add("numbikesavailable", IntegerType)
      .add("mechanical", IntegerType)
      .add("ebike", IntegerType)
      .add("is_renting", StringType)
      .add("is_returning", StringType)
      .add("duedate", StringType)
      .add("coordonnees_geo", StringType)
      .add("nom_arrondissement_communes", StringType)
      .add("code_insee_commune", StringType)

    // Fonction pour lire et traiter chaque fichier CSV
    def processFile(filePath: String, spark: SparkSession): DataFrame = {
      val df = spark.read
        .option("delimiter", ";") // Spécifier le délimiteur correct
        .schema(schema)
        .csv(filePath)

      val dfNonNull = df.na.fill(0, Seq("capacity", "numdocksavailable", "numbikesavailable"))
        .na.fill("Inconnu", Seq("nom_arrondissement_communes"))

      val kpiDF = dfNonNull
        .withColumn("occupation_rate", (coalesce($"numbikesavailable", lit(0)) / coalesce($"capacity", lit(1))) * 100)
        .withColumn("dock_availability_rate", (coalesce($"numdocksavailable", lit(0)) / coalesce($"capacity", lit(1))) * 100)
        .withColumn("mechanical_percentage", (coalesce($"mechanical", lit(0)) / coalesce($"numbikesavailable", lit(1))) * 100)
        .withColumn("ebike_percentage", (coalesce($"ebike", lit(0)) / coalesce($"numbikesavailable", lit(1))) * 100)
        .withColumn("is_full", when($"numdocksavailable" === 0, 1).otherwise(0))
        .withColumn("is_empty", when($"numbikesavailable" === 0, 1).otherwise(0))
        .groupBy("stationcode", "name", "nom_arrondissement_communes")
        .agg(
          first("coordonnees_geo").as("coordonnees_geo"),
          sum("numbikesavailable").as("total_bikes_available"),
          avg("occupation_rate").as("avg_occupation_rate"),
          avg("dock_availability_rate").as("avg_dock_availability_rate"),
          avg("mechanical_percentage").as("avg_mechanical_percentage"),
          avg("ebike_percentage").as("avg_ebike_percentage"),
          sum("is_full").as("full_stations"),
          sum("is_empty").as("empty_stations")
        )

      kpiDF
    }

    // Lire tous les fichiers du répertoire de sortie
    val inputDir = "C:\\Users\\DELL\\Downloads\\Projet_Spark_streaming\\output"
    val files = new File(inputDir).listFiles.filter(_.getName.endsWith(".csv")).sorted

    val kpiDir = "C:\\Users\\DELL\\Downloads\\Projet_Spark_streaming\\output_kpis"
    new File(kpiDir).mkdirs()

    val outputFilePath = s"$kpiDir/resultat_kpis.csv"

    // Initialiser le fichier de sortie avec l'en-tête correct
    val header = "stationcode;name;nom_arrondissement_communes;coordonnees_geo;total_bikes_available;avg_occupation_rate;avg_dock_availability_rate;avg_mechanical_percentage;avg_ebike_percentage;full_stations;empty_stations"
    Files.write(Paths.get(outputFilePath), (header + "\n").getBytes, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)

    // Boucle pour traiter les fichiers périodiquement
    var nextRunTime = LocalDateTime.now()
    files.foreach { file =>
      var currentTime = LocalDateTime.now()
      while (currentTime.isBefore(nextRunTime)) {
        // Boucle d'attente active jusqu'à ce que l'heure prévue pour le prochain traitement soit atteinte
        currentTime = LocalDateTime.now()
      }

      val kpiDF = processFile(file.getAbsolutePath, spark)

      val outputDirPath = s"$kpiDir/resultat_kpis_temp"
      kpiDF.coalesce(1).write.mode("overwrite").option("header", "true").option("delimiter", ";").csv(outputDirPath)

      // Déplacer le fichier part en un seul fichier CSV
      val partFile = new File(outputDirPath).listFiles().filter(_.getName.startsWith("part-")).head
      val lines = Files.readAllLines(partFile.toPath).asScala

      // Filtrer les lignes pour éviter d'ajouter l'en-tête incorrect
      val content = lines.tail.filterNot(line => line.contains(";0;\"\";\"\";\"\";\"\";1;1"))

      // Ajouter le contenu au fichier de sortie final
      Files.write(Paths.get(outputFilePath), content.asJava, StandardOpenOption.APPEND)

      // Supprimer le répertoire temporaire
      new File(outputDirPath).listFiles().foreach(_.delete())
      new File(outputDirPath).delete()

      // Mettre à jour le temps de la prochaine exécution
      nextRunTime = LocalDateTime.now().plusMinutes(intervalMinutes)
    }

    println(s"Processed ${files.length} files, saved to $outputFilePath")
    spark.stop()
  }
}