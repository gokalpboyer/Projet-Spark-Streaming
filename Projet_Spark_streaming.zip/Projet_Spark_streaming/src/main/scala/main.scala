object main {
  def main(args: Array[String]): Unit = {
    // Run LireCSVVelib
    LireCSVVelib.main(args)

    // After LireCSVVelib finishes, run application
    application.main(args)
  }
}
 